<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>PHP Exercise - Data Types</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: lightcyan;
            margin: 0;
            padding: 0;
            color: #3e3e3e;
        }

        .navlist {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin-bottom: 30px;
            gap: 10px;
        }

        .navlist a {
            padding: 15px 25px;
            text-decoration: none;
            color: black;
            font-weight: bold;
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 8px;
            transition: transform 0.3s ease, background-color 0.3s ease;
        }

        .navlist a:hover {
            transform: scale(1.1);
            background-color: lightblue;
        }

        h1 {
            text-align: center;
            color: #5e4b3c;
            padding: 32px 16px 10px;
            font-size: 28px;
        }

        .home-btn {
            position: fixed;
            top: 15px;
            left: 20px;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 12px 18px;
            border-radius: 8px;
            font-weight: bold;
            text-decoration: none;
            color: black;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s ease, background-color 0.3s ease;
            z-index: 1000;
        }

        .home-btn:hover {
            background-color: lightcyan;
            transform: scale(1.05);
        }

        .container {
            background-color: #fffaf2;
            border-left: 5px solid #c8ad7f;
            padding: 20px 24px;
            margin: 20px auto;
            width: 90%;
            max-width: 720px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            border-radius: 12px;
            transition: box-shadow 0.3s ease;
        }

        .container:hover {
            animation: shake 0.5s ease-in-out;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }

        @keyframes shake {
            0% { transform: translate(0px, 0px) rotate(0deg); }
            25% { transform: translate(-2px, 2px) rotate(-1deg); }
            50% { transform: translate(2px, -2px) rotate(1deg); }
            75% { transform: translate(-1px, 2px) rotate(0deg); }
            100% { transform: translate(0px, 0px) rotate(-1deg); }
        }

        .container h2 {
            margin-top: 0;
            color: #8b6f47;
            font-size: 20px;
            margin-bottom: 10px;
        }

        p {
            margin: 6px 0;
            font-size: 15px;
        }
    </style>
</head>
<body>
<a href="Home.html" class="home-btn">Home</a>

    <h1>PHP Exercises Control Structures</h1>

    <nav class="navlist">
       
       <a href="Exercise1.php">Data Types</a>
       <a href="Exercise2.php">Control Structures</a>
       <a href="exercise3.php">Functions</a>
       <a href="Exercise4.php">Build-In Functions</a>
   </nav>

    <div class="container">
        <h2>Exercise 1: Highest and Lowest Value</h2>
    
       <?php
    $a = 35;
    $b = 20;

    if ($a > $b) {
        echo "Highest value is $a<br>";
        echo "Lowest value is $b";
    } elseif ($b > $a) {
        echo "Highest value is $b<br>";
        echo "Lowest value is $a";
    } else {
        echo "Both values are equal: $a";
    }
?>
    </div>


      <div class="container">
        <h2>Exercise 2: Cards(Baraha)</h2>
<?php
$value = 3;

if ($value == 1) {
    echo "Spades";
} elseif ($value == 2) {
    echo "Hearts";
} elseif ($value == 3) {
    echo "Diamonds";
} elseif ($value == 4) {
    echo "Clubs";
} else {
    echo "Invalid value. Please enter a number between 1 and 4.";
}
 ?>
 </div>
 <div class="container">
        <h2>Exercise 3: Grading System</h2>
        <?php
$score = 75;

if ($score >= 90 && $score <= 100) {
    $grade = 'A';
    $status = 'passed';
} elseif ($score >= 80 && $score <= 89) {
    $grade = 'B';
    $status = 'passed';
} elseif ($score >= 70 && $score <= 79) {
    $grade = 'C';
    $status = 'passed';
} elseif ($score >= 60 && $score <= 69) {
    $grade = 'D';
    $status = 'failed';
} elseif ($score < 60) {
    $grade = 'F';
    $status = 'failed';
} else {
    $grade = 'Invalid';
    $status = 'Unknown';
}

echo "The student scored $score points.<br>";
echo "The Student Grade is: $grade<br>";
echo "The student has $status the exam.";
         ?>
       </div>  
<div class="container">
        <h2>Exercise 4: Leap Year</h2>
<?php 
$year = 2024;

if ($year % 400 == 0 || $year % 4 == 0) {
    echo "$year is a leap year.";
} else {
    echo "$year is not a leap year.";
}
?>
</div>
<div class="container">
        <h2>Exercise 5: Machine Replacement/Repair</h2>
        <?php

$workingHours = 12000;
$ageInYears = 8;
$failuresPerYear = 20;

if ($workingHours > 10000 || $ageInYears > 7 || $failuresPerYear > 25) {
    echo "The machine should be replaced.";
} else {
    echo "The machine is still in good condition.";
}
?>
</div>
 <div class="container">
        <h2>Exercise 6: Multiplication table</h2>
        <?php 
$number = 7;

$start = 1;
$end = 10;

echo "Multiplication table for $number:<br>";
for ($i = $start; $i <= $end; $i++) {
    $result = $number * $i;
    echo "$number x $i = $result<br>";
}
        ?>
    </div>
 <div class="container">
        <h2>Exercise 7: Fibonacci </h2>
<?php
$fib1 = 0;
$fib2 = 1;

echo "Fibonacci series from 0 to 50:<br>";
echo "$fib1, $fib2";

while (true) {
    $next = $fib1 + $fib2;
    if ($next > 50) {
        break;
    }
    echo ", $next";

    $fib1 = $fib2;
    $fib2 = $next;
}
?>
</body>
</html>
