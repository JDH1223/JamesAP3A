<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>PHP Exercise - Data Types</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: lightgreen;
            margin: 0;
            padding: 0;
            color: #3e3e3e;
        }

        h1 {
            text-align: center;
            color: #5e4b3c;
            padding: 32px 16px 10px;
            font-size: 28px;
        }

        .navliste {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin-bottom: 30px;
            gap: 10px;
        }

        .navliste a {
            padding: 15px 25px;
            text-decoration: none;
            color: black;
            font-weight: bold;
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 8px;
            transition: transform 0.3s ease, background-color 0.3s ease;
        }

        .navliste a:hover {
            transform: scale(1.1);
            background-color: lightseagreen;
        }

        .home-btn {
            position: fixed;
            top: 15px;
            left: 20px;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 12px 18px;
            border-radius: 8px;
            font-weight: bold;
            text-decoration: none;
            color: black;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s ease, background-color 0.3s ease;
            z-index: 1000;
        }

        .home-btn:hover {
            background-color: lightcyan;
            transform: scale(1.05);
        }

        .container {
            background-color: #fffaf2;
            border-left: 5px solid #c8ad7f;
            padding: 20px 24px;
            margin: 20px auto;
            width: 90%;
            max-width: 720px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            border-radius: 12px;
            transition: box-shadow 0.3s ease;
        }

        .container:hover {
            animation: shake 0.5s ease-in-out;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }

        @keyframes shake {
            0% { transform: translate(0px, 0px) rotate(0deg); }
            25% { transform: translate(-2px, 2px) rotate(-1deg); }
            50% { transform: translate(2px, -2px) rotate(1deg); }
            75% { transform: translate(-1px, 2px) rotate(0deg); }
            100% { transform: translate(0px, 0px) rotate(-1deg); }
        }

        .container h2 {
            margin-top: 0;
            color: #8b6f47;
            font-size: 20px;
            margin-bottom: 10px;
        }

        p {
            margin: 6px 0;
            font-size: 15px;
        }
    </style>
</head>
<body>
<a href="Home.html" class="home-btn">Home</a>

    <h1>PHP User Defined Functions Exercises</h1>

    <nav class="navliste">
       <a href="Exercise1.php">Data Types</a>
       <a href="Exercise2.php">Control Structures</a>
       <a href="exercise3.php">Functions</a>
       <a href="Exercise4.php">Build-In Functions</a>
   </nav>

    <div class="container">
        <h2>Exercise 1. Vat Calculator</h2>
        <p>
        <?php
        $price = 100;
        $vat = 0.15;

        function calculateVat($price, $vat) {
            $calculatedPrice = $price + ($price * $vat);
            return $calculatedPrice;
        }

        $totalPrice = calculateVat($price, $vat);

        echo "Price is: $price<br>";
        echo "VAT is: " . ($vat * 100) . "%<br>";
        echo "Total price is: $totalPrice";
        ?>
        </p>
    </div>

    <div class="container">
        <h2>Exercise 2. Leap Year</h2>
        <p>
        <?php
        $year = 2024;

        function isLeapYear($year) {
            return ($year % 400 == 0 || $year % 4 == 0 && $year % 100 != 0);
        }

        if (isLeapYear($year)) {
            echo "$year is a leap year";
        } else {
            echo "$year is not a leap year";
        }
        ?>
        </p>
    </div>

    <div class="container">
    <h2>Exercise 3. Calculator</h2>
    <p>
    <?php
    $num1 = 20;
    $num2 = 5;

    function addNumbers($a, $b) {
        return $a + $b;
    }

    function subtractNumbers($a, $b) {
        return $a - $b;
    }

    function multiplyNumbers($a, $b) {
        return $a * $b;
    }

    function divideNumbers($a, $b) {
        return $b != 0 ? $a / $b : 'Division by zero not allowed';
    }

    echo "Addition of $num1 and $num2 is " . addNumbers($num1, $num2) . "<br>";
    echo "Subtraction of $num1 and $num2 is " . subtractNumbers($num1, $num2) . "<br>";
    echo "Multiplicity of $num1 and $num2 is " . multiplyNumbers($num1, $num2) . "<br>";
    echo "Division of $num1 and $num2 is " . divideNumbers($num1, $num2);
    ?>
    </p>
</div>

<div class="container">
    <h2>Exercise 4. Swapping Numbers</h2>
    <p>
    <?php
    $num1 = 4;
    $num2 = 8;

    echo "Before swapping: num1 = $num1, num2 = $num2<br>";

    function swapNumbers($a, $b) {
        $temp = $a;
        $a = $b;
        $b = $temp;
        echo "After swapping: num1 = $a, num2 = $b";
    }

    swapNumbers($num1, $num2);
    ?>
    </p>
</div>

<div class="container">
    <h2>Exercise 5. Even or Odd</h2>
    <p>
    <?php
    $num1 = 7;

    function evenOrNot($num) {
        if ($num % 2 == 0) {
            echo "Num1 is even";
        } else {
            echo "Num1 is odd";
        }
    }

    evenOrNot($num1);
    ?>
    </p>
</div>

<div class="container">
    <h2>Exercise 6. Prime Number</h2>
    <p>
    <?php
    $num1 = 17;

    function isPrime($num) {
        if ($num <= 1) return false;
        for ($i = 2; $i <= sqrt($num); $i++) {
            if ($num % $i == 0) return false;
        }
        return true;
    }

    if (isPrime($num1)) {
        echo "$num1 is a prime number";
    } else {
        echo "$num1 is not a prime number";
    }
    ?>
    </p>
</div>


</body>
</html>
