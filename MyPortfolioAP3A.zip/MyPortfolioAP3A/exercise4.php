<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>PHP</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: lightpink;
            margin: 0;
            padding: 0;
            color: #3e3e3e;
        }

        h1 {
            text-align: center;
            color: #5e4b3c;
            padding: 32px 16px 10px;
            font-size: 28px;
        }

        .home-btn {
            position: fixed;
            top: 15px;
            left: 20px;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 12px 18px;
            border-radius: 8px;
            font-weight: bold;
            text-decoration: none;
            color: black;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s ease, background-color 0.3s ease;
            z-index: 1000;
        }

        .home-btn:hover {
            background-color: lightcyan;
            transform: scale(1.05);
        }

        .navlist {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin-bottom: 30px;
            gap: 10px;
        }

        .navlist a {
            padding: 15px 25px;
            text-decoration: none;
            color: black;
            font-weight: bold;
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 8px;
            transition: transform 0.3s ease, background-color 0.3s ease;
        }

        .navlist a:hover {
            transform: scale(1.1);
            background-color: lightpink;
        }

        .container {
            background-color: #fffaf2;
            border-left: 5px solid #c8ad7f;
            padding: 20px 24px;
            margin: 20px auto;
            width: 90%;
            max-width: 720px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            border-radius: 12px;
            transition: box-shadow 0.3s ease;
        }

        .container:hover {
            animation: shake 0.5s ease-in-out;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }

        @keyframes shake {
            0% { transform: translate(0px, 0px) rotate(0deg); }
            25% { transform: translate(-2px, 2px) rotate(-1deg); }
            50% { transform: translate(2px, -2px) rotate(1deg); }
            75% { transform: translate(-1px, 2px) rotate(0deg); }
            100% { transform: translate(0px, 0px) rotate(-1deg); }
        }

        .container h2 {
            margin-top: 0;
            color: #8b6f47;
            font-size: 20px;
            margin-bottom: 10px;
        }

        p {
            margin: 6px 0;
            font-size: 15px;
        }
    </style>
</head>
<body>

    <a href="Home.html" class="home-btn">Home</a>

    <h1>PHP Build Functions Exercises</h1>

    <nav class="navlist">
        <a href="Exercise1.php">Data Types</a>
        <a href="Exercise2.php">Control Structures</a>
        <a href="exercise3.php">Functions</a>
        <a href="Exercise4.php">Build-In Functions</a>
    </nav>

   
    <div class="container">
        <h2>Exercise 1. Sorting Array</h2>
        <p>
        <?php
        $NUMBERS = [34,64,14,18,56,1];
        rsort($NUMBERS);
        echo "Sorted array in descending order: ";
        foreach ($NUMBERS as $num) {
            echo $num . " ";
        }
        ?>
        </p>
    </div>

    <div class="container">
        <h2>Exercise 2. Birthday Countdown</h2>
        <p>
        <?php
        $today = new DateTime();
        $birthday = new DateTime(date('Y') . '-12-15');
        if ($birthday < $today) {
            $birthday->modify('+1 year');
        }
        $interval = $today->diff($birthday);
        echo "There are " . $interval->days . " days left until your birthday!";
        ?>
        </p>
    </div>

    <div class="container">
        <h2>Exercise 3. Generating Random Float Numbers</h2>
        <p>
        <?php
        function randNumber($min, $max) {
            return $min + mt_rand() / mt_getrandmax() * ($max - $min);
        }
        $randomFloat = randNumber(1, 10);
        echo "Generated random float number: $randomFloat";
        ?>
        </p>
    </div>

    <div class="container">
        <h2>Exercise 4. Lowercase Check</h2>
        <p>
        <?php
        $str = "Learning PHP IS FUN AND VERY INTERESTING. Let's PRACTICE EVERYDAY!";
        function lowercaseCheck($text) {
            return strtolower($text);
        }
        $lowerStr = lowercaseCheck($str);
        echo "Original Text: $str<br>";
        echo "Lowercase Text: $lowerStr";
        ?>
        </p>
    </div>

    <div class="container">
        <h2>Exercise 5. Search Inside of a Text</h2>
        <p>
        <?php
        function searchText($str, $punctuation) {
            $count = substr_count($str, $punctuation);
            echo "The text has $count '$punctuation' punctuation(s).";
        }
        $text = "Hello! How are you doing today? I hope everything's fine. Let's meet at 5:00 p.m.";
        searchText($text, ".");
        ?>
        </p>
    </div>

    <div class="container">
        <h2>Exercise 6. Lowest and Highest Values</h2>
        <p>
        <?php
        $onlyNumbers = [25, 8, 42, 17, 3, 99, 64];
        $minValue = min($onlyNumbers);
        $maxValue = max($onlyNumbers);
        echo "The lowest value is $minValue and the highest value is $maxValue";
        ?>
        </p>
    </div>

    <div class="container">
        <h2>Exercise 7. String Repeat</h2>
        <p>
        <?php
        $str = "Hello! ";
        $repeated = str_repeat($str, 8);
        echo $repeated;
        ?>
        </p>
    </div>

</body>
</html>
