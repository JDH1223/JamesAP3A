<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Laboratory Activities</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #fdf6ec;
            margin: 0;
            padding: 0;
            color: #3e3e3e;
        }

        .home-button {
            position: absolute;
            top: 20px;
            left: 20px;
            text-decoration: none;
            background-color: #c8ad7f;
            color: white;
            padding: 10px 16px;
            border-radius: 8px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .home-button:hover {
            background-color: #a98f65;
        }

        h1 {
            text-align: center;
            color: #5e4b3c;
            padding: 32px 16px 10px;
            font-size: 28px;
            margin: 0;
        }

        .container {
            background-color: #fffaf2;
            border-left: 5px solid #c8ad7f;
            padding: 20px 24px;
            margin: 20px auto;
            width: 90%;
            max-width: 700px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            border-radius: 12px;
            transition: box-shadow 0.3s ease, transform 0.3s ease;
        }

        .container:hover {
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            transform: translateY(-3px);
        }

        .container a {
            text-decoration: none;
            color: #8b6f47;
        }

        .container h2 {
            margin-top: 0;
            color: #8b6f47;
            font-size: 20px;
            margin-bottom: 10px;
        }

        .container p {
            margin: 6px 0;
            font-size: 15px;
        }

        .footer {
            text-align: center;
            padding: 20px;
            font-weight: bold;
            background-color: #f8f2e8;
            color: #5e4b3c;
        }

        @media (max-width: 768px) {
            h1 {
                font-size: 24px;
            }

            .container {
                margin: 16px;
                width: auto;
            }

            .footer {
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <a href="Home.html" class="home-button">Home</a>

    <h1>PHP Laboratory Activities</h1>

    <div class="container">
        <h2><a href="Exercise1.php">Exercises 1</a></h2>
        <p>Php Data Types</p>
    </div>

    <div class="container">
        <h2><a href="Exercise2.php">Exercises 2</a></h2>
        <p>Php Control Structures</p>
    </div>

    <div class="container">
        <h2><a href="exercise3.php">Exercises 3</a></h2>
        <p>Php Functions</p>
    </div>

    <div class="container">
        <h2><a href="Exercise4.php">Exercises 4</a></h2>
        <p>Php Built-In Functions</p>
    </div>

    <div class="footer">
        &copy; James D. Herminigildo
    </div>
</body>
</html>
