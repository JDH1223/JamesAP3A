<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>PHP Exercise - Data Types</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color:lightgoldenrodyellow;
            margin: 0;
            padding: 0;
            color: #3e3e3e;
        }

        h1 {
            text-align: center;
            color: #5e4b3c;
            padding: 32px 16px 10px;
            font-size: 28px;
        }

        .container {
            background-color: #fffaf2;
            border-left: 5px solid #c8ad7f;
            padding: 20px 24px;
            margin: 20px auto;
            width: 90%;
            max-width: 720px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            border-radius: 12px;
            transition: box-shadow 0.3s ease;
        }

        .container:hover {
            animation: shake 0.5s ease-in-out;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }

        @keyframes shake {
            0% { transform: translate(0px, 0px) rotate(0deg); }
            25% { transform: translate(-2px, 2px) rotate(-1deg); }
            50% { transform: translate(2px, -2px) rotate(1deg); }
            75% { transform: translate(-1px, 2px) rotate(0deg); }
            100% { transform: translate(0px, 0px) rotate(-1deg); }
        }

        .container h2 {
            margin-top: 0;
            color: #8b6f47;
            font-size: 20px;
            margin-bottom: 10px;
        }
        .home-btn {
            position: fixed;
            top: 15px;
            left: 20px;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 12px 18px;
            border-radius: 8px;
            font-weight: bold;
            text-decoration: none;
            color: black;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s ease, background-color 0.3s ease;
            z-index: 1000;
        }

        .home-btn:hover {
            background-color: lightcyan;
            transform: scale(1.05);
        }

        p {
            margin: 6px 0;
            font-size: 15px;
        }
        .navlist {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin-bottom: 30px;
            gap: 10px;
        }

        .navlist a {
            padding: 15px 25px;
            text-decoration: none;
            color: black;
            font-weight: bold;
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 8px;
            transition: transform 0.3s ease, background-color 0.3s ease;
        }

        .navlist a:hover {
            transform: scale(1.1);
            background-color: lightcyan;
        }

    </style>
</head>
<body>

<a href="Home.html" class="home-btn">Home</a>

    <h1>PHP - Data Types Exercises</h1>
    <nav class="navlist">
       
        <a href="Exercise1.php">Data Types</a>
        <a href="Exercise2.php">Control Structures</a>
        <a href="exercise3.php">Functions</a>
        <a href="Exercise4.php">Build-In Functions</a>
    </nav>
    <div class="container">
        <h2>Exercise 1. Personal Information</h2>
        <p>
        <?php
            $x = 8;
            $y = 4;
            $z = ($x + $y) * 5;
            echo "The total is $z";
        ?>
        </p>
    </div>

    <div class="container">
        <h2>Exercise 2. Value Added Tax</h2>
        <p>
        <?php 
            $price = 100;
            $vat = 15;
            $totalPrice = $price + ($price * $vat / 100);
            echo "Price: $price<br>";
            echo "VAT: $vat%<br>";
            echo "Total price: $totalPrice";
        ?>
        </p>
    </div>

    <div class="container">
        <h2>Exercise 3. Average</h2>
        <p>
        <?php
            $x = 20;
            $y = 30;
            $z = 40;
            $average = ($x + $y + $z) / 3;
            $averageformatted = number_format($average, 2);
            echo "The average is $averageformatted";
        ?>
        </p>
    </div>

    <div class="container">
        <h2>Exercise 4. Countries and Capitals</h2>
        <p>
        <?php
            $countries = array(
                "Netherlands" => "Amsterdam",
                "Thailand" => "Bangkok",
                "Germany" => "Berlin",
                "Japan" => "Tokyo",
                "Philippines" => "Manila"
            );
            foreach ($countries as $country => $capital) {
                echo "The capital of $country is $capital<br>";
            }
        ?>
        </p>
    </div>

    <div class="container">
        <h2>Exercise 5. Centimeters to Inches</h2>
        <p>
        <?php 
            $cm = 66;
            $inch = 0.39;
            $cmToInch = $cm * $inch;
            echo "$cm centimeters is $cmToInch inches.";
        ?>
        </p>
    </div>

    <div class="container">
        <h2>Exercise 6. Expenses</h2>
        <p>
        <?php
            $expenses = [100, 150, 300, 600, 50];
            $totalAmount = 0;
            $amountOfExpenses = count($expenses);
            foreach ($expenses as $expense) {
                $totalAmount += $expense;
            }
            echo "My $amountOfExpenses biggest expenses were $totalAmount.";
        ?>
        </p>
    </div>
</body>
</html>
